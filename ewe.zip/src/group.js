import config from '../config.js'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'
import { readFileSync } from 'fs'
import baileys from '@whiskeysockets/baileys'

const __dirname = dirname(fileURLToPath(import.meta.url))
const { jidNormalizedUser } = baileys

export default async function (Dudul, update) {
	const from = update.id
	const nomor = update.participants[0]
	
	if (update.action == 'add') {
		const botNumber = jidNormalizedUser(Dudul.user.id)
		const ownerList = [botNumber, config.owner.number, ...config.owner.additionalOwner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
		const groupMetadata = await Dudul.groupMetadata(from).catch(() => {})
		const participants = groupMetadata?.participants || []
		const getAdminList = (participants.reduce((memberAdmin, memberNow) => (memberNow.admin ? memberAdmin.push({ id: memberNow.id, admin: memberNow.admin }) : [...memberAdmin]) && memberAdmin, []))
		const isBotAdmins = !!getAdminList.find((member) => member.id === botNumber)
		const isOwner = ownerList.includes(nomor)
		const isBanned = await Dudul.bannedCheck(nomor)
		
		if (isBotAdmins && !isOwner && !isBanned && (nomor.startsWith('62') || nomor.startsWith('60'))) console.log('<!>', nomor.split('@')[0], 'masuk ke', (groupMetadata?.subject || 'suatu grup'))
		if (isBanned && isBotAdmins && !isOwner) Dudul.groupParticipantsUpdate(from, [nomor], 'remove').then(() => console.log('<<BAN>>', nomor.split('@')[0], 'kick dari', (groupMetadata?.subject || 'suatu grup')))
		if (!isBanned && isBotAdmins && !isOwner && !nomor.startsWith('62') && !nomor.startsWith('60')) Dudul.groupParticipantsUpdate(from, [nomor], 'remove')
	}
}
