import config from '../config.js'
import axios from 'axios'
import FormData from 'form-data'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'
import { readFileSync } from 'fs'
import baileys from '@whiskeysockets/baileys'

const __dirname = dirname(fileURLToPath(import.meta.url))
const { downloadContentFromMessage, generateWAMessageFromContent, prepareWAMessageMedia, proto, jidNormalizedUser, getContentType, extractMessageContent } = baileys

export default async function (Dudul, update) {
	const mek = update.messages[0]
	if (!mek.message) return
	//if (mek.key.fromMe) return
	
	const from = mek.key.remoteJid
	const isGroup = from.endsWith('@g.us')
	const type = await getContentType(mek.message)
	const sender = isGroup ? mek.key.participant : from
	const messageBody = extractMessageContent(mek.message[type]) || mek.message[type]
	const viewOnceMessage = mek?.message?.viewOnceMessageV2?.message || ''
	const mediaViewOnce = viewOnceMessage?.imageMessage || viewOnceMessage?.videoMessage || ''
	const body = messageBody?.text || messageBody?.conversation || messageBody?.caption || mediaViewOnce?.caption || mek.message?.conversation || messageBody?.selectedButtonId || messageBody?.singleSelectReply?.selectedRowId || messageBody?.selectedId || messageBody?.contentText || messageBody?.selectedDisplayText || messageBody?.title || messageBody?.name || ''
	const botNumber = jidNormalizedUser(Dudul.user.id)
	const ownerList = [botNumber, config.owner.number, ...config.owner.additionalOwner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
	
	const groupMetadata = isGroup ? await Dudul.groupMetadata(from).catch(() => {}) : {}
	const participants = groupMetadata?.participants || []
	const groupName = groupMetadata?.subject || ''
	const getAdminList = (participants.reduce((memberAdmin, memberNow) => (memberNow.admin ? memberAdmin.push({ id: memberNow.id, admin: memberNow.admin }) : [...memberAdmin]) && memberAdmin, []))
	const isAdmins = !!getAdminList.find((member) => member.id === sender)
	const isBotAdmins = !!getAdminList.find((member) => member.id === botNumber)
	const isOwner = ownerList.includes(sender)
	const isBanned = await Dudul.bannedCheck(sender)
	
	if (isBotAdmins || isOwner) Dudul.readMessages([mek.key])
	if (isBotAdmins && !isOwner && body && type && body.length < 70) console.log('\n[!] Pesan dari', sender.split('@')[0], 'nick', (mek?.pushName || 'Tanpa nama'), 'di', (groupMetadata?.subject || 'Chat Pribadi'), '~>', body)
	if (isGroup && isBotAdmins && !isAdmins && !isOwner) {
		const isCheckpoint = config.textCheckpoint.exec(body)
		if (isBanned) return Dudul.sendMessage(from, { delete: mek.key }).then(() => Dudul.groupParticipantsUpdate(from, [sender], 'remove')).catch(() => {})
		if (!viewOnceMessage && isCheckpoint) {
			for (let point of isCheckpoint) {
				const replyForward = await Dudul.sendMessage(config.owner.number +'@s.whatsapp.net', { forward: mek }).catch(() => {})
				await Dudul.sendMessage(from, { delete: mek.key }).catch(() => {})
				if (body.length > 15) {
					if (body.length > 30) {
						if (!isBanned) Dudul.banedUser(sender)
						if (config.autoKickFromAllGroup) {
							const groupPointParticipating = await Dudul.groupFetchAllParticipating()
							const filterPoitGroup = Object.entries(groupPointParticipating).slice(0).map((entry) => entry[1])
							const getPointGroupID = filterPoitGroup.map((v) => v.id)
							for (let fromPointId of getPointGroupID) {
								await Dudul.groupParticipantsUpdate(fromPointId, [sender], 'remove').catch(() => {})
							}
						} else {
							await Dudul.groupParticipantsUpdate(from, [sender], 'remove').catch(() => {})
						}
					} else {
						await Dudul.groupParticipantsUpdate(from, [sender], 'remove').catch(() => {})
					}
				}
				await Dudul.sendMessage(config.owner.number +'@s.whatsapp.net', { text: `*Nama* : ${mek?.pushName || 'Tanpa nama'}\n*Pengirim* : @${sender.split('@')[0]}\n*Nomor* : ${sender.split('@')[0]}\n*Grup* : ${groupMetadata?.subject || 'Tanpa subject'}\n*Text* : ${point}`, mentions: [sender] }, { quoted: replyForward })
			}
		}
		
		if (viewOnceMessage && isCheckpoint) {
			for (let _point of isCheckpoint) {
				await Dudul.sendMessage(from, { delete: mek.key }).catch(() => {})
				if (body.length > 6) {
					if (body.length > 10) {
						if (!isBanned) Dudul.banedUser(sender)
						if (config.autoKickFromAllGroup) {
							const _groupPointParticipating = await Dudul.groupFetchAllParticipating()
							const _filterPoitGroup = Object.entries(_groupPointParticipating).slice(0).map((entry) => entry[1])
							const _getPointGroupID = _filterPoitGroup.map((v) => v.id)
							for (let _fromPointId of _getPointGroupID) {
								await Dudul.groupParticipantsUpdate(_fromPointId, [sender], 'remove').catch(() => {})
							}
						} else {
							await Dudul.groupParticipantsUpdate(from, [sender], 'remove').catch(() => {})
						}
					} else {
						await Dudul.groupParticipantsUpdate(from, [sender], 'remove').catch(() => {})
					}
				}
				
				if (config.sendViewOnce) {
					let viewOnceMediaType = mediaViewOnce.mimetype.split('/')[0]
					let downloadViewOnceMedia = await downloadContentFromMessage(mediaViewOnce, viewOnceMediaType)
					let captionMediaOnce = `*KONTOL SEKALI LIHAT*\n\n*Pengirim* : @${sender.split('@')[0]}\n*Nama* : ${mek?.pushName || ''}\n*Grup* : ${groupName}\n*Text* : ${_point}\n\n*Caption* : ${mediaViewOnce?.caption || ''}`
					let setViewOnceBuffer = Buffer.from([])
					for await (const chunkViewOnce of downloadViewOnceMedia) {
						setViewOnceBuffer = Buffer.concat([setViewOnceBuffer, chunkViewOnce])
					}
					
					if (/video/.test(viewOnceMediaType)) {
						await Dudul.sendMessage(config.owner.number +'@s.whatsapp.net', {
							video: setViewOnceBuffer,
							caption: captionMediaOnce,
							mentions: [sender]
						})
					}
					if (/image/.test(viewOnceMediaType)) {
						await Dudul.sendMessage(config.owner.number +'@s.whatsapp.net', {
							image: setViewOnceBuffer,
							caption: captionMediaOnce,
							mentions: [sender]
						})
					}
				}
			}
		}
		
		if (!sender.startsWith('62') && !sender.startsWith('60')) Dudul.sendMessage(from, { delete: mek.key }).then(() => Dudul.groupParticipantsUpdate(from, [sender], 'remove')).catch(() => {})
		if (body.length > 150) Dudul.sendMessage(from, { delete: mek.key }).then(() => Dudul.groupParticipantsUpdate(from, [sender], 'remove')).catch(() => {})
		if (body == null) Dudul.sendMessage(from, { delete: mek.key }).catch(() => {})
		if (body == undefined) Dudul.sendMessage(from, { delete: mek.key }).catch(() => {})
		if (type == null) Dudul.sendMessage(from, { delete: mek.key }).catch(() => {})
		if (type == undefined) Dudul.sendMessage(from, { delete: mek.key }).catch(() => {})
		if (type == 'pollCreationMessage') Dudul.sendMessage(from, { delete: mek.key }).catch(() => {})
		if (type == 'contactMessage') Dudul.sendMessage(from, { delete: mek.key }).catch(() => {})
		if (type == 'documentMessage') Dudul.sendMessage(from, { delete: mek.key }).catch(() => {})
		if (type == 'audioMessage') Dudul.sendMessage(from, { delete: mek.key }).catch(() => {})
		if (type == 'locationMessage') Dudul.sendMessage(from, { delete: mek.key }).catch(() => {})
		if (type == 'liveLocationMessage') Dudul.sendMessage(from, { delete: mek.key }).catch(() => {})
		if (type == 'contactsArrayMessage') Dudul.sendMessage(from, { delete: mek.key }).then(() => Dudul.groupParticipantsUpdate(from, [sender], 'remove')).catch(() => {})
	}
	
	if (isOwner || isAdmins) {
		const prefix = config.cmdPrefix.test(body) ? body.match(config.cmdPrefix)[0] : '#'
		const isCmd = body.startsWith(prefix)
		const command = body.replace(prefix, '').trim().split(/ +/).shift()
		const setCase = isCmd ? command.toLowerCase() : ''
		const args = body.trim().split(/ +/).slice(1)
		const teks = args.join(' ')
		
		switch (setCase) {
			case 'tes':
			case 'cek':
			case 'kiw':
			case 'bot':
				let processUptime = process.uptime()
				let day = Math.floor(processUptime / (3600 * 24))
				let hour = Math.floor(processUptime % (3600 * 24) / 3600)
				let minute = Math.floor(processUptime % 3600 / 60)
				let second = Math.floor(processUptime % 60)
				let dDisplay = day > 0 ? day + (day == 1 ? ' hari ' : ' hari ') : ''
				let hDisplay = hour > 0 ? hour + (hour == 1 ? ' jam ' : ' jam ') : ''
				let mDisplay = minute > 0 ? minute + (minute == 1 ? ' menit ' : ' menit ') : ''
				let sDisplay = second > 0 ? second + (second == 1 ? ' detik ' : ' detik ') : ''
				let timed = dDisplay + hDisplay + mDisplay + sDisplay
				let checkBot = `Hay ${mek?.pushName || 'kontol'}\n\n*${Dudul?.user?.name || 'Gueh'}* Udah Aktif Selama.\n- ${timed}`
				await Dudul.sendMessage(from, { text: checkBot }, { quoted: mek })
			break
			
			case 'tai':
			case 'bacot':
			case 'kontol':
			case 'berisik':
			case 'kick':
			case 'hode':
			case 'tipu':
			case 'tolol':
				if (!isGroup) return Dudul.sendMessage(from, { text: 'Gunakan ini di dalam grup' }, { quoted: mek })
				if (!isBotAdmins) return Dudul.sendMessage(from, { text: 'Perlu jabatan sebagai admin' }, { quoted: mek })
				if (!messageBody?.contextInfo?.participant && !messageBody?.contextInfo?.mentionedJid && !teks) return Dudul.sendMessage(from, { text: 'Masukan Nomor / Reply / Tag Orang nya' }, { quoted: mek })
				if (messageBody?.contextInfo?.stanzaId) Dudul.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: messageBody.contextInfo.stanzaId, participant: messageBody.contextInfo.participant }}).catch(() => {})
				await Dudul.sendMessage(from, { delete: mek.key }).catch(() => {})
				
				let nomorForKick = messageBody?.contextInfo?.participant || messageBody?.contextInfo?.mentionedJid[0] || teks +'@s.whatsapp.net' || null
				let groupKickParticipating = await Dudul.groupFetchAllParticipating()
				let filterKickGroup = Object.entries(groupKickParticipating).slice(0).map((entry) => entry[1])
				let getKickGroupID = filterKickGroup.map((v) => v.id)
				let isBannedFromKick = await Dudul.bannedCheck(nomorForKick)
				
				if (!isBannedFromKick) Dudul.banedUser(nomorForKick)
				await Dudul.groupParticipantsUpdate(from, [nomorForKick], 'remove').catch(() => {})
			break
			
			case 'join':
			case 'masuk':
				if (!isOwner) return Dudul.sendMessage(from, { text: 'Hanya untuk owner' }, { quoted: mek })
				if (!teks) return Dudul.sendMessage(from, { text: `Contoh :\n~> *${prefix + command}* link grup` }, { quoted: mek })
				let groupID = args[0].split('https://chat.whatsapp.com/')[1]
				await Dudul.groupAcceptInvite(groupID).then(() => Dudul.sendMessage(from, { text: 'Berhasil' }, { quoted: mek })).catch(() => Dudul.sendMessage(from, { text: 'Gagal' }, { quoted: mek }))
			break
			
			case 'leave':
			case 'keluar':
				if (!isOwner) return Dudul.sendMessage(from, { text: 'Hanya untuk owner' }, { quoted: mek })
				if (!isGroup) return Dudul.sendMessage(from, { text: 'Gunakan ini di dalam grup' }, { quoted: mek })
				await Dudul.groupLeave(from).catch(() => Dudul.sendMessage(from, { text: 'Gagal' }, { quoted: mek }))
			break
			
			case 'revoke':
			case 'resetlink':
			case 'linkgc':
				if (!isGroup) return Dudul.sendMessage(from, { text: 'Gunakan ini di dalam grup' }, { quoted: mek })
				if (!isBotAdmins) return Dudul.sendMessage(from, { text: 'Perlu jabatan sebagai admin' }, { quoted: mek })
				await Dudul.groupRevokeInvite(from).catch(() => Dudul.sendMessage(from, { text: 'Gagal' }, { quoted: mek }))
				let gcid = await Dudul.groupInviteCode(from).catch(() => console.log('Gagal mendapatkan id chat grup'))
				await Dudul.groupUpdateDescription(from, `*Sebarin Link Grup Nya Biar Rame*\n\n_https://chat.whatsapp.com/${gcid}_`).catch(() => {})
			break
			
			case 'upload':
			case 'groupsor':
			case 'grupsor':
				if (!teks) return Dudul.sendMessage(from, { text: `Contoh :\n~> *${prefix + command}* link grup` }, { quoted: mek })
				
				try {
					let _response = await axios.get('https://groupsor.link')
					let setCookieHeader = _response.headers['set-cookie']
					let cookieValue = setCookieHeader[0].split(';')[0]
					
					let formData = new FormData()
					formData.append('glink', teks)
					formData.append('gcid', '7')
					formData.append('cid', '30')
					formData.append('lid', '3')
					
					let response = await axios.post('https://groupsor.link/data/addgroup', formData, {
						headers: {
							'Content-Type': `multipart/form-data; boundary=${formData.getBoundary()}`,
							'Cookie': cookieValue
						}
					})
					
					if (response.data === '') {
						await Dudul.sendMessage(from, { text: 'Berhasil' }, { quoted: mek })
					} else {
						await Dudul.sendMessage(from, { text: `Info error : ${response?.data || 'tidak ada data'}` }, { quoted: mek })
					}
				} catch (err) {
					Dudul.sendMessage(from, { text: 'Error' }, { quoted: mek })
				}
			break
			
			
			case 'spam':
			case 'send':
			case 'kirim':
				if (!isOwner) return Dudul.sendMessage(from, { text: 'Hanya untuk owner' }, { quoted: mek })
				if (!teks) return Dudul.sendMessage(from, { text: `Contoh :\n~> *${prefix + command}* link grup` }, { quoted: mek })
				if (type !== 'extendedTextMessage') return Dudul.sendMessage(from, { text: `Contoh :\n~> *${prefix + command}* sambil reply chat` }, { quoted: mek })
				let groupIDspam = args[0].split('https://chat.whatsapp.com/')[1]
				let igGcToSpam = await Dudul.groupAcceptInvite(groupIDspam).catch(() => {})
				let getSpamForward = await proto.WebMessageInfo.fromObject({
					key: {
						id: messageBody.contextInfo.stanzaId,
						participant: messageBody.contextInfo.participant
					},
					message: messageBody.contextInfo.quotedMessage
				})
				await Dudul.sendMessage(igGcToSpam, { forward: getSpamForward }).then(async () => {
					await Dudul.sendMessage(igGcToSpam, { forward: getSpamForward }).then(async () => {
						await Dudul.sendMessage(igGcToSpam, { forward: getSpamForward }).then(async () => {
							await Dudul.sendMessage(from, { text: 'Done' }, { quoted: mek })
						}).catch(() => {})
					}).catch(() => {})
				}).catch(() => Dudul.sendMessage(from, { text: 'Gagal' }, { quoted: mek }))
				await Dudul.groupLeave(igGcToSpam).catch(() => {})
			break
			
			case 'idgc':
				let getGroupsid = await Dudul.groupFetchAllParticipating()
				let groupsid = Object.entries(getGroupsid).slice(0).map((entry) => entry[1])
				let anuid = groupsid.map((v) => v.id)
				let teksid = `⬣ *LIST GROUP ANDA*\n\nTotal Group : ${anuid.length} GROUP\n\n`
				
				for (let x of anuid) {
					let metadata2 = await Dudul.groupMetadata(x)
					teksid += `❏  ${metadata2.subject}\n┠─ *ID :* ${metadata2.id}\n┠─ *STATUS :* GROUP\n╰────| ANGGOTA : ${metadata2.participants.length}\n\n`
				}
				
				Dudul.sendMessage(from, { text: teksid }, { quoted: mek})
			break
			
			case 'push':
				if (!teks) return Dudul.sendMessage(from, { text: `Contoh :\n~> *${prefix + command}* idgc|teks` }, { quoted: mek })
				const metadata2 = await Dudul.groupMetadata(teks.split("|")[0])
				const halss = metadata2.participants
				
				for (let mem of halss) {
					await Dudul.sendMessage(`${mem.id.split('@')[0]}` + "@s.whatsapp.net", { text: teks.split("|")[1]} )
					await Dudul.sleeping(3000)
				}
			break
		}
	}
}