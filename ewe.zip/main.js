process.on('unhandledRejection', (err) => console.error(err))

import config from './config.js'
import pino from 'pino'
import axios from 'axios'
import FormData from 'form-data'
import nodecache from 'node-cache'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'
import { readFileSync, writeFileSync } from 'fs'
import { Boom } from '@hapi/boom'
import baileys from '@whiskeysockets/baileys'

const __dirname = dirname(fileURLToPath(import.meta.url))
const { makeInMemoryStore, jidNormalizedUser, useMultiFileAuthState, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, DisconnectReason } = baileys
const pairingCode = !!config.bot.pairingBotNumber || process.argv.includes('--pairing-code')
const useMobile = process.argv.includes('--mobile')
const banned = JSON.parse(readFileSync(join(__dirname, 'src', 'lib', 'banned.json')))
const store = makeInMemoryStore({
	logger: pino().child({
		level: 'silent',
		stream: 'store'
	})
})

async function start() {
	const { version } = await fetchLatestBaileysVersion() 
	const { state, saveCreds } = await useMultiFileAuthState(join(__dirname, 'src', 'session', config.bot.sessionsName))
	const msgRetryCounterCache = new nodecache()
	const Dudul = baileys.default({
		version,
		logger: pino({
			level: 'silent'
		}).child({
			level: 'silent'
		}),
		printQRInTerminal: !pairingCode,
		mobile: useMobile,
		auth: {
			creds: state.creds,
			keys: makeCacheableSignalKeyStore(state.keys, pino({
				level: 'silent'
			}).child({
				level: 'silent'
			}))
		},
		browser: ['Chrome (Linux)', '', ''],
		markOnlineOnConnect: true,
		generateHighQualityLinkPreview: true,
		defaultQueryTimeoutMs: undefined,
		msgRetryCounterCache
	})
	store?.bind(Dudul.ev)
	Dudul.ev.on('creds.update', saveCreds)
	Dudul.ev.on('connection.update', async (update) => {
		const { receivedPendingNotifications, connection, lastDisconnect, isOnline } = update	
		if (connection == 'connecting') console.log('Menghubungkan')
		if (connection == 'open') console.log('Terhubung', (jidNormalizedUser(Dudul.user.id)?.split('@')[0] || ''))
		if (isOnline) console.log('Online')
		if (receivedPendingNotifications) console.log((Dudul?.user?.name || 'Bot'), 'Siap Digunakan')
		if (connection === 'close') {
			const reason = new Boom(lastDisconnect?.error)?.output.statusCode
			if (reason !== DisconnectReason.loggedOut) {
				console.log('Mulai Ulang')
				await start()
			}
		}
	})
	Dudul.ev.on('contacts.update', (update) => {
		for (let contact of update) {
			let id = jidNormalizedUser(contact.id)
			if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
		}
	})
	Dudul.ev.on('messages.upsert', async (update) => {
		await (await import('./src/message.js')).default(Dudul, update)
	})
	Dudul.ev.on('group-participants.update', async (update) => {
		await (await import('./src/group.js')).default(Dudul, update)
	})
	if (pairingCode && !Dudul.authState.creds.registered) {
		if (useMobile) console.log('Tidak dapat menggunakan kode penyandingan dengan api seluler')
		setTimeout(async () => {
			const requestVerifyCode = await Dudul.requestPairingCode(config.bot.pairingBotNumber)
			const getVerifyCode = requestVerifyCode?.match(/.{1,4}/g)?.join('-') || requestVerifyCode
			console.log('Kode :', getVerifyCode)
		}, 3000)
	}
	Dudul.banedUser = (jid) => {
		const objek = { id: jid }
		banned.push(objek)
		writeFileSync(join(__dirname, 'src', 'lib', 'banned.json'), JSON.stringify(banned, null, 2))
	}
	Dudul.bannedCheck = (jid) => {
		let status = false
		Object.keys(banned).forEach((i) => {
			if (banned[i].id === jid) {
				status = true
			}
		})
		return status
	}
	Dudul.sleeping = (ms) => {
		return new Promise(resolve => setTimeout(resolve, ms));
	}
	return Dudul
}

start()