export default {
	bot: {
		pairingBotNumber: '62838967723496',
		sessionsName: 'poke'
	},
	
	owner: {
		number: '62838967723496',
		additionalOwner: []
	},
	
	autoKickFromAllGroup: false,
	sendViewOnce: true,
	
	textCheckpoint: /http|https|whatsapp.com|wa.me|bayar|tarif|syarat|order|test|ready|readi|saldo|bonus|open|dana|ovo|gopay|qris|puas|basi|list|oven|bit|biz|com/i,
	cmdPrefix: /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i
}
